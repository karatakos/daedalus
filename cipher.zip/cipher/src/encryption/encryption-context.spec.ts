import { EncryptionContext } from "./encryption-context.js";
import { PrimeNumberEncryption } from "./strategies/prime/prime-encryption-strategy.js";
import { PrimeGenerator } from "./strategies/prime/prime-generator.js";
import { EncryptionError } from "./strategies/contracts.js";
import { Ok, NotOk } from "./utility/result.js";

describe("Encryption context", () => {
  it('should encrypt and decrypt some input', () => {
    const key = "SUPERMAN";
    const input = "Hello, my name is John. How are you today?"

    const context = new EncryptionContext(
      new PrimeNumberEncryption(new PrimeGenerator()));

    const e = context.encrypt(input, key);
    expect(e).toBeInstanceOf(Ok);

    if (e instanceof Ok) {
      const d = context.decrypt(e.content, key);
      expect(d).toBeInstanceOf(Ok);

      if (d instanceof Ok) {
        expect(d.content).toBe(input);
      }
    }
  });

  it('should encrypt and match some output', () => {
    const key = "SUPERMAN";
    const input = "Hello, my name is John. How are you today?"

    const context = new EncryptionContext(
      new PrimeNumberEncryption(new PrimeGenerator()));

    const e = context.encrypt(input, key);
    expect(e).toBeInstanceOf(Ok);

    if (e instanceof Ok) {
      expect(e.content).toBe("{F8ZSZjPy9l**fC%T$+poR* qH9W=7<\\w~iB'f$rN-");
    }
  });

  it('should encrypt and decrypt large message', () => {
    const key = "largemessage";
    const input = "The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. We`re done here.";

    const context = new EncryptionContext(
      new PrimeNumberEncryption(new PrimeGenerator()));

    const e = context.encrypt(input, key);
    expect(e).toBeInstanceOf(Ok);

    if (e instanceof Ok) {
      const d = context.decrypt(e.content, key);
      expect(d).toBeInstanceOf(Ok);

      if (d instanceof Ok) {
        expect(d.content).toBe(input);
      }
    }
  });

  it('should reject bad key', () => {
    const context = new EncryptionContext(
      new PrimeNumberEncryption(new PrimeGenerator()));

    const key = "keycontains␆controlchar";
    const input = "The quick brown fox jumps over the lazy dog.";

    const e = context.encrypt(input, key);
    expect(e).toBeInstanceOf(NotOk);

    if (e instanceof NotOk) {
      expect(e.error).toBe(EncryptionError.InvalidKey);
    }
  });

  it('should reject bad input', () => {
    const context = new EncryptionContext(
      new PrimeNumberEncryption(new PrimeGenerator()));

    const key = "goodkey";
    const input = "but bad ␆ input that includes control char.";

    const e = context.encrypt(input, key);
    expect(e).toBeInstanceOf(NotOk);

    if (e instanceof NotOk) {
      expect(e.error).toBe(EncryptionError.InvalidInput);
    }
  });
});

