export type Result<T, E> = Ok<T> | NotOk<E>;

export class Ok<T> { constructor( public content: T) {}};
export class NotOk<T> { constructor( public error: T) {}};

export const ok = <T, > (value: T): Ok<T> => { return new Ok(value) }
export const notok = <T, > (error: T): NotOk<T> => { return new NotOk(error) }