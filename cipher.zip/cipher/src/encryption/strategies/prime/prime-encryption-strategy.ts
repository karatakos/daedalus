import { type IEncryptionStrategy, EncryptionError } from "../contracts.js";
import { type Result, ok, notok } from "../../utility/result.js";
import type { PrimeGenerator } from "./prime-generator.js";

const lower = 32;
const upper = 126;
const span = upper-lower + 1;   // Inclusive diff

export class PrimeNumberEncryption implements IEncryptionStrategy {
    constructor(private pgen: PrimeGenerator) {}

    private getN(position: number, key: string): number {
        const c = key.charCodeAt(position % key.length);
        if (!this.isCharValid(c)) {
            return -1;
        }

        return position + c;
    }

    private isCharValid(c: number): boolean {
        return c >= lower && c <= upper;
    }

    public encrypt (text: string, key: string): Result<string, EncryptionError> {
        if (!text) {
            return notok(EncryptionError.EmptyInput);
        }

        if (!key) {
            return notok(EncryptionError.EmptyKey);
        }

        let out = "";
        for(let i = 0; i < text.length; i++) {
            let c = text.charCodeAt(i);

            if (!this.isCharValid(c)) {
                return notok(EncryptionError.InvalidInput);
            }

            let n = this.getN(i, key);
            if (n < 0) {
                return notok(EncryptionError.InvalidKey);
            }

            let ec = this.pgen.getPrimeAtN(n) + i + c;

            // Tried span first, switched to mod by upper as it wasn't working. However this meant
            // adding an if statement (mod if ec is > upper) which caused issues with the reversal during decrypt
            // Finally resolved by normalizing to 0 based (lower) before mod and then re-adding lower.
            // I also wasted time initially thinking ec cannot be reversed forgetting reversal isnt necessary since i can calculate the same prime again
            //
            // ((x - a) % m) + a
            //
            ec = ((ec - lower) % span) + lower;

            //console.log(`EC: ${ec}; EC Char: ${String.fromCharCode(ec)}`);

            out += String.fromCharCode(ec);  
        }

        //console.log(`Encrypted: ${out}`);

        return ok(out);
    }

    public decrypt (text: string, key: string):  Result<string, EncryptionError> {
        if (!text) {
            return notok(EncryptionError.EmptyInput);
        }

        if (!key) {
            return notok(EncryptionError.EmptyKey);
        }

        let out = "";
        for(let i = 0; i < text.length; i++) {
            let c = text.charCodeAt(i);

            let n = this.getN(i, key)
            if (n < 0) {
                return notok(EncryptionError.InvalidKey);
            }

            let ic = c - i - this.pgen.getPrimeAtN(n);

            // Spent the most time getting this right (see mod comment in encrypt method)
            // This of works only because we're able to calculate the same prime (as well as the index since input/output length is the same)
            //
            // Breaking: ((x - a + m) % m) + a + m -- not handling the negative case for the new consts
            // 
            // ((x - a) % m + m) % m + a 
            //
            let dc = ((ic - lower) % span + span) % span + lower;

            //console.log(`IC: ${ic}; DC: ${dc}; DC Char: ${String.fromCharCode(dc)}`);

            out += String.fromCharCode(dc);
        }
        
        //console.log(`Decrypted: ${out}`);

        return ok(out);
    }
}
