import { PrimeGenerator } from "./prime-generator.js";

describe("Primer generator", () => {
  it('should detect prime', () => {
    const pGen = new PrimeGenerator([]);

    expect(pGen.isPrime(71)).toBe(true);
  });

  it('should calculate Nth prime numnber', () => {
    const pGen = new PrimeGenerator([]);

    const p20 = pGen.getPrimeAtN(20);

    expect(p20).toBe(71);
  });
});
