
export class PrimeGenerator {
  constructor(private primes: number[] = []) { }

  public isPrime(n: number): boolean {
    if (n <= 1) {
      return false;
    }

    if (n == 2 || n == 3) {
      return true;
    }

    if (n % 2 == 0 || n % 3 == 0) {
      return false;
    }

    const sqrt = Math.floor(Math.sqrt(n));
    for (let i = 5; i <= sqrt; i + 2) {
      if (n % i == 0) {
        return false;
      }
    }

    return true;
  }

  public getPrimeAtN(n: number): number {
    if (n == 0) {
      throw new Error("N must be greater than 0");
    }

    if (this.primes.length >= n) {
      return this.primes[n - 1];
    }

    let cur = 0;
    if (this.primes.length) {
      cur = this.primes[this.primes.length - 1] + 1;
    }

    while (this.primes.length < n) {
      if (this.isPrime(cur)) {
        this.primes.push(cur);
      }

      cur++;
    }

    if (this.primes.length != n) {
      // Something went wrong
      //
      throw new Error(`Prime could not be generated for N = ${n}`)
    }

    return this.primes[n - 1];
  }
}
