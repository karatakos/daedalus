import type { Result } from '../utility/result.js';

export enum EncryptionError{
  EmptyInput = "Empty Input",
  EmptyKey = "Empty Key",
  InvalidInput = "Input Contains Invalid Character",
  InvalidKey = "Key Contains Invalid Character"
}

export interface IEncryptionStrategy {
  encrypt(value: string, key: string): Result <string, EncryptionError>;
  decrypt(value: string, key: string): Result <string, EncryptionError>;
}
