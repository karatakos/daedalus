import type { IEncryptionStrategy, EncryptionError } from './strategies/contracts.js'
import type { Result } from './utility/result.js'

export class EncryptionContext {
  constructor (private strategy: IEncryptionStrategy) {}

  public encrypt(value: string, key: string): Result <string, EncryptionError> { return this.strategy.encrypt(value, key); }
  public decrypt(value: string, key: string): Result <string, EncryptionError> { return this.strategy.decrypt(value, key); }
}
