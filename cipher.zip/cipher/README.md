# Run

npm install
npm run test

# Note

1. Time spent: ~4 hours. Problem areas: Reversing the modulus operation for decrypt; First time leveraging type union for a result type (usually would just use a single type); Getting jest to run with ts caused some issues.
1. Test coverage: 90%.
1. For factoring primes i use the only approach I remember but it seems to work fine for smaller primes (see comments). A quick Google search yields better options.
1. I cache primes by indice for better performance over multiple usages the idea being you can feed Prime Generator a table of primes. I have not provided unit tests to validate that this is working as intended.
1. Have not added any telemtry for timing or measured extremely large message sizes. Encrypt and decrypt happy path test case takes ~700 ms on average (5 runs).
1. Only provided evidence via tests, there is no index.ts.
