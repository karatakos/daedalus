// jest.config.cjs or jest.config.js with export default
/** @type {import('ts-jest').JestConfigWithTsJest} */
const config = { // or module.exports = {
  preset: 'ts-jest/presets/default-esm', // Use the ESM preset
  testEnvironment: 'node',
  transform: {
    '^.+\\.tsx?$': ['ts-jest', { useESM: true }],
  },
  // Optional: Add moduleNameMapper if you encounter path resolution issues
  moduleNameMapper: {
    '^(\\.{1,2}/.*)\\.js$': '$1',
  },
};
export default config; // or module.exports = config;