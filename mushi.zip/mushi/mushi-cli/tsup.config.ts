import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/index.ts'],
  format: ['esm'],
  dts: true,
  shims: true,
  clean: true,
  // 1. Force these to stay as real Node imports
  external: ['buffer', 'stream', 'util'],
  // 2. Manually define require at the top level
  banner: {
    js: `import { createRequire } from 'module'; const require = createRequire(import.meta.url);`,
  },
  // 3. Keep mushi inside the bundle if you prefer, but externalize its problematic deps
  noExternal: ['mushi'],
});
