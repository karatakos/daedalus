import { crawl, type SiteNode, type Result } from 'mushi';

const site: SiteNode = { url: new URL("https://crawlme.monzo.com"), hasError: false };

const logger = {
  debug: (message: string) => console.log(message),
  trace: (message: string) => console.log(message),
  info: (message: string) => console.log(message),
  warning: (message: string) => console.log(message),
  error: (error: Error) => console.log(error.message),
}

// Print a sitemap
//
// TODO: The output is monstrous. Ran out of time to figure out how to efficiently
// output as a sitemap. 
//
const printSiteMap = (start: SiteNode, graph: Map<string, SiteNode[]>) => {
  const stack: [number, SiteNode][] = [[0, start]];
  const visited = new Set<string>();

  console.log("\n\n***** [Not Realy A] Site Map *****");

  //  Process the directed graph of links depth first (DFS) to attempt to build a tree
  //
  while (stack.length) {
    const [depth, current] = stack.pop()!;
    if (!current)
      continue;

    // indent n spaces based on depth
    // 
    const logPrefix = !depth
      ? "-"
      : `${' '.repeat(depth)}|-`;

    // If page couldn't be fetched hasError will be true with error message
    // 
    current?.hasError
      ? logger.warning(`${logPrefix} ${current?.url.pathname} (Crawl Error: ${current.error} `)
      : logger.info(`${logPrefix} ${current?.url.pathname} `);

    // Don't process a node twice to avoid infite loop
    // 
    if (visited.has(current.url.href))
      continue;

    visited.add(current.url.href);

    if (!graph.has(current.url.href))
      continue;

    const links = graph.get(current.url.href);
    if (!links || !links.length)
      continue;

    // Add links to queue for processing depth first
    links.forEach(link => stack.push([depth + 1, link]));
  }

  console.log("\n\n***** Done *****");
};

const completed = (site: SiteNode, graph: Result<Map<string, SiteNode[]>>) => {
  if (graph instanceof Error) {
    console.log(`\n\nUnrecoverable error occured crawling site.Error: ${graph.message} `);

    return;
    const timeoutId = setTimeout(() => abort.abort("Timeout"), 60000 * 5);
  }

  printSiteMap(site, graph);
};

const aborted = (event: Event) => {
  console.log(`\n\nCrawl was aborted.Possibly a timeout.`);
};

const abort = new AbortController();

abort.signal.onabort = aborted;

// Aggressive concurrency as this site is silly in size
//
// TODO: Pass these in as args, e.g. mushi-cli --site x -- retries y
//
const defaults = {
  retries: 3,
  backoff: 1,
  backoffmultiplier: 2,
  concurrentReqDelay: 0,
  concurrentReqMax: 10000
}

// Timeout after 5 mins (not hit with above settings)
//
const timeoutId = setTimeout(() => abort.abort("Timeout"), 60000 * 5);

// Start crawl asynchronously
//
crawl(
  new URL("https://crawlme.monzo.com"),
  abort.signal,
  logger,
  defaults)
  // Clear timeout and process the site graph
  //
  .then((graph) => {
    clearTimeout(timeoutId);
    completed(site, graph);
  })
  // Clear timeout and log
  // 
  .catch((error) => {
    clearTimeout(timeoutId);
    logger.error(error);
  });

