# Mushi-cli

## Build

```bash
npm install
npm link
npm run build

## Run

```bash
npm run mushi-cli https://crawlme.monzo.com
```
