# Mushi

Web crawler library

# Build & Test

npm run Build
npm run test

**Deploy Locally**
npm link

# Deploy

npm publish
