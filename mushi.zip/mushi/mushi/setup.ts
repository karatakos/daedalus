
import createFetchMock from "vitest-fetch-mock";
import { vi } from "vitest";

const fetchMocker = createFetchMock(vi);
fetchMocker.enableMocks();

// Force Vitest to replace the global fetch with the mock instance
vi.stubGlobal("fetch", fetchMocker);

console.log("Setup loaded");
