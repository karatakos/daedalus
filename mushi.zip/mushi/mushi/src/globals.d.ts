
declare const fetchMock: any;
