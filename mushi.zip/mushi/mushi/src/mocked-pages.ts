
export const home = `
<html>
  <body>
    <nav>
      <a href="index.html">Home</a>
      <a href="about.html">About</a>
    </nav>
    <main>
      <ul>
        <li><a href="help.html">Help Center</a></li>
      </ul>
    </main>
  </body>
</html>
`;

export const about = `
<html>
  <body>
    <nav>
      <a href="index.html">Home</a>
      <a href="about.html">About</a>
    </nav>
    <main>
      <ul>
        <li><a href="contact.html">Contacts</a></li>
      </ul>
    </main>
  </body>
</html>
`;

export const contact = `
<html>
  <body>
    <main>
      <ul>
        <li><a href="mailto:contact@crawlertest.example.com">Mail Us</a></li>
        <li><a href="tel:11111111">Phone Us</a></li>
        <li><a href="terms.htm">TnCs</a></li>
        <li><a href="https://www.google.com">Google</a></li>
      </ul>
    </main>
  </body>
</html>
`;

export const terms = `
<html>
  <body>
    <main>
      <ul>
        <li><a href="contact.html">Contacts</a></li>
      </ul>
    </main>
  </body>
</html>
`;

export const help = `
<html>
  <body>
    <main>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="tel:11111111">Phone Us</a></li>
      </ul>
    </main>
  </body>
</html>
`;

export const retry = `
<html>
  <body>
    <main>
      <ul>
        <li><a href="500.html">500 Error</a></li>
      </ul>
    </main>
  </body>
</html>
`
export const noretry = `
<html>
  <body>
    <main>
      <ul>
        <li><a href="403.html">403 Forbidden</a></li>
      </ul>
    </main>
  </body>
</html>
`;
