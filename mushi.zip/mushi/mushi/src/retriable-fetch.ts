
export async function fetchRetry(
  uri: URL,
  retries: number,
  backoff: number,
  backOffMultiplier: number,
  request: RequestInit): Promise<Response> {

  let response;
  try {
    response = await fetch(uri, request);

    if (!response.ok) {
      console.log(`nok fetch. Status: ${response.status}`);

      // Likely unrecoverable (malformed, forbidden, etc.)
      //
      // TODO: For rate limit hit (429) we may want a larger backoff multiplier
      //
      if (response.status < 500 && response.status != 429)
        return response;

      if (retries > 0) {
        console.log(`Waiting for ${backoff} ms before retry`);

        // Respect backoff period before retry
        await new Promise(resolve => setTimeout(resolve, backoff));

        return await fetchRetry(
          uri,
          retries - 1,
          backoff * backOffMultiplier,
          backOffMultiplier,
          request);
      }
    }
  }
  catch (error) {
    // Abort signal (voluntary so return)
    //
    if (error instanceof DOMException && error.name === 'AbortError')
      throw error;

    if (retries <= 0)
      throw error;

    return await fetchRetry(
      uri,
      retries - 1,
      backoff * backOffMultiplier,
      backOffMultiplier,
      request);
  }

  return response;
}
