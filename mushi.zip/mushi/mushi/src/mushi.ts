import { load } from 'cheerio';

import { fetchRetry } from './retriable-fetch.js'

import EventEmitter from 'node:events';

/* Options for retry and backoff strategy
 */
export type Opts = {
  retries: number, // # retries
  backoff: number, // Ms between retries
  backoffmultiplier: number, // # multiplier for subsequent retries
  concurrentReqDelay: number, // Ms delay between batch of concurrent requests
  concurrentReqMax: number, // # max concurrent fetch requests
}

/* Primitive Maybe
 */
export type Result<T> = T | Error;

/* Crude interface for a logger passed in from the client
 */
export interface Logger {
  trace: (message: string) => void,
  debug: (message: string) => void,
  info: (message: string) => void,
  warning: (message: string) => void,
  error: (error: Error) => void,
}

export type SiteNode = {
  url: URL,
  hasError: boolean,
  error?: string
}

const defaults: Opts = {
  retries: 3,
  backoff: 1,
  backoffmultiplier: 2,
  concurrentReqDelay: 50,
  concurrentReqMax: 5,
}

/**
  * Crawls pages of a site
  *
  * @remarks Does not respect robots.txt or sitemap.xml
  *
  * @param uri Site to start crawl
  * @param Logger Object implementing Logger interface
  * @param signal AbortSignal for cancellation
  * @param opts Opts for retry and backoff control
  *
  * @returns Adjacency list representing page relationships 
  *          that can be read like any graph structure
  */
export async function crawl(
  uri: URL,
  signal: AbortSignal,
  logger?: Logger,
  opts: Opts = defaults): Promise<Result<Map<string, SiteNode[]>>> {

  const options = { ...defaults, ...opts };

  const graph = new Map<string, SiteNode[]>();
  const visited = new Set<string>();

  const queue: SiteNode[] = [];

  const fetchCompletedEvent = new EventEmitter();

  const baseNode = { url: uri, hasError: false };
  queue.push(baseNode);

  let inflightRequestCounter = 0;

  logger?.info(`Starting crawl for  site: ${baseNode.url.href}`);

  while (true) {
    if (!queue.length) {
      logger?.debug(`Queue empty. Waiting if requests in flight. Inflight requests: ${inflightRequestCounter}`);

      if (!inflightRequestCounter)
        break;

      // Nothing to process but we have inflight page requests so wait for one!
      //
      await new Promise(resolve => fetchCompletedEvent.once('completed', resolve));

      continue;
    }

    if (signal.aborted)
      return new Error(`Aborted by caller. Reason: ${signal.reason ?? "No reason"}`);

    let batchRequestCounter = 0;

    while (queue.length && batchRequestCounter < opts.concurrentReqMax) {
      // Take the first-in for FIFO processing
      const current = queue.shift();

      // Ignore if we've already processed this request
      //
      if (!current || visited.has(current.url.href))
        break;

      visited.add(current.url.href);

      if (!graph.has(current.url.href))
        graph.set(current.url.href, []);

      // Track requests to keep within max batch size
      batchRequestCounter++;

      // Track inflight pages request
      inflightRequestCounter++;

      logger?.info(`Attemping fetch for ${current.url.href}`);

      // Attempt a page fetch with smart retry
      // 
      fetchPageContent(current.url, options, signal)
        .then(result => {
          if (result instanceof Error) {
            // TODO: Since we're using a <string, SiteNode> adjanceny list the root URL SiteNode 
            //       won't be available in the graph on failure. Refactor graph data structure or 
            //       have crawl return error.
            //
            current.hasError = true;
            current.error = result.message;

            logger?.warning(`Error occured fetching page but will continue crawl: ${current.url.href}`);

            return;
          }

          const html: string = result!;

          if (!html) {
            logger?.warning(`Ignoring: ${current.url.href}. Reason: Null or empty html`);

            return;
          }

          let links: SiteNode[] = extractDistinctLinks(current.url, html)
            .map(link => ({ url: link, hasError: false }));

          // Add edges to our current site node
          graph.get(current.url.href)!.push(...links);

          // Queue links for crawling
          queue.push(...links);

          logger?.info(`Successfully crawled page: ${current.url.href}`);
        })
        .catch((error) => {
          // Swallow the error but keep track in the graph
          current.hasError = true;
          current.error = error.message;
        })
        .finally(() => {
          inflightRequestCounter--;

          fetchCompletedEvent.emit('completed');
        })
    }

    if (queue.length && options.concurrentReqDelay) {
      logger?.debug(`Waiting ${options.concurrentReqDelay} until next crawl.`);

      // Wait before processing the next batch
      //
      // TODO: Request could be added to queue within ms of this delay not kicking in
      await new Promise(resolve => setTimeout(resolve, options.concurrentReqDelay));
    }
  }

  return graph;
}

async function fetchPageContent(uri: URL, options: Opts, signal: AbortSignal): Promise<Result<string | undefined>> {
  const request = {
    method: "GET",
    headers: {
      "user-agent": "scrappy/1.0",
    },
    signal: signal
  };

  let html;

  try {
    const response = await fetchRetry(
      uri,
      options.retries,
      options.backoff,
      options.backoffmultiplier,
      request);

    if (!response.ok)
      return new Error("Try again later.");

    html = await response.text();
  }
  catch (error: any) {
    if (error instanceof DOMException && error.name === "AbortError")
      return new Error("Aborted by caller.");

    return error;
  }

  return html;
}

function extractDistinctLinks(baseUri: URL, html: string): URL[] {
  const urls = new Map<string, URL>();

  if (!html)
    return [];

  try {
    const $ = load(html);
    $('a').each((index, element) => {
      const href = $(element).attr('href');
      if (!href)
        return;

      const uri = new URL(href, baseUri);

      if (urls.has(uri.href))
        return;

      if (!isAllowedURL(baseUri, uri))
        return;

      urls.set(uri.href, uri);
    });
  }
  // TODO: Invalid HTML we crawled something we shouldnt
  catch { }

  return [...urls.values()];
}

function isAllowedURL(baseUri: URL, link: URL): boolean {
  if (baseUri.host != link.host)
    return false;

  // Match only htm or html (case insensitive)
  if (!link.pathname.match(/\.html?$/i))
    return false;

  return true;
}
