import { beforeEach, afterEach, describe, it, expect } from 'vitest';

import { home, about, contact, terms, help, retry, noretry } from "./mocked-pages.js";
import { crawl, type SiteNode } from './mushi.js';

const homeUri = new URL("https://crawlme.monzo.com/");
const contactUri = new URL("https://crawlme.monzo.com/contact.html");
const aboutUri = new URL("https://crawlme.monzo.com/about.html");
const helpUri = new URL("https://crawlme.monzo.com/help.html");
const termsUri = new URL("https://crawlme.monzo.com/terms.htm");
const retryUri = new URL("https://crawlme.monzo.com/retry.html");
const noretryUri = new URL("https://crawlme.monzo.com/noretry.html");
const forbiddenUri = new URL("https://crawlme.monzo.com/403.html");
const errorUri = new URL("https://crawlme.monzo.com/500.html");

const logger = {
  debug: (message: string) => console.log(message),
  trace: (message: string) => console.log(message),
  info: (message: string) => console.log(message),
  warning: (message: string) => console.log(message),
  error: (error: Error) => console.log(error.message),
}

beforeEach(() => {
  fetchMock.mockResponse((req: any) => {
    const url = req.url;

    console.log(`Fetch intercepted for: ${url}`);

    // happy path scenarios
    //
    if (url === "https://crawlme.monzo.com/") return Promise.resolve(home);
    if (url.includes("/index.html")) return Promise.resolve(home);
    if (url.includes("/about.html")) return Promise.resolve(about);
    if (url.includes("/help.html")) return Promise.resolve(help);
    if (url.includes("/terms.htm")) return Promise.resolve(terms);
    if (url.includes("/contact.html")) return Promise.resolve(contact);

    // Retry scenario
    if (url.includes("/retry.html")) return Promise.resolve(retry);
    if (url.includes("500.html")) return Promise.resolve({
      ok: false,
      status: 500,
      json: () => Promise.resolve({ message: 'Not Found' }), // Mock the response body
    })

    // Unrecoverable error scenario
    if (url.includes("/noretry.html")) return Promise.resolve(noretry);
    if (url.includes("403.html")) return Promise.resolve({
      ok: false,
      status: 403,
      json: () => Promise.resolve({ message: 'Forbidden' }), // Mock the response body
    })

    // unrecoverable excepion scenario
    return Promise.reject(new Error(`Unhandled request to: ${url}`));
  });
});

afterEach(() => {
  fetchMock.resetMocks();
});

describe('Mushi crawl request', () => {
  it("should fetch expected links from site", async () => {
    const abort = new AbortController();

    const response = await crawl(
      homeUri,
      abort.signal,
      logger);

    expect(fetchMock).toHaveBeenCalledTimes(6);
    expect(response).toBeInstanceOf(Map);

    if (response instanceof Map) {
      expect(response.entries().toArray().length).toBe(6);

      expect(response.get(homeUri.href)?.length).toBe(3);
      expect(response.get(contactUri.href)?.length).toBe(1);
      expect(response.get(aboutUri.href)?.length).toBe(3);
      expect(response.get(helpUri.href)?.length).toBe(1);
      expect(response.get(termsUri.href)?.length).toBe(1);
    }
  });

  it("should retry 3 times for 500 error", async () => {
    const abort = new AbortController();

    const response = await crawl(
      retryUri,
      abort.signal,
      logger);

    expect(fetchMock).toHaveBeenCalledTimes(5); // 1 for retry.html, 1 for 500.html + 3 retries
    expect(response).toBeInstanceOf(Map);

    if (response instanceof Map) {
      expect(response.entries().toArray().length).toBe(2);

      expect(response.get(retryUri.href)?.length).toBe(1);
      expect(response.get(errorUri.href)?.length).toBe(0);
    }
  });

  it("should not retry for 403 error", async () => {
    const abort = new AbortController();

    const response = await crawl(
      noretryUri,
      abort.signal,
      logger);

    expect(fetchMock).toHaveBeenCalledTimes(2); // 1 for noretry.html, 1 for 403.html (no retries)
    expect(response).toBeInstanceOf(Map);

    if (response instanceof Map) {
      expect(response.entries().toArray().length).toBe(2);

      // response.forEach((val, key) => console.log(`Key: ${key}; Values: ${val}`));

      expect(response.get(noretryUri.href)?.length).toBe(1);
      expect(response.get(forbiddenUri.href)?.length).toBe(0);
    }
  });

  it("should show crawl error for failed page fetch", async () => {
    const abort = new AbortController();

    const response = await crawl(
      noretryUri,
      abort.signal,
      logger);

    expect(fetchMock).toHaveBeenCalledTimes(2); // 1 for noretry.html, 1 for 403.html (no retries)
    expect(response).toBeInstanceOf(Map);

    if (response instanceof Map) {
      expect(response.get(noretryUri.href)?.length).toBe(1);

      expect(response.get(noretryUri.href)![0]?.hasError).toBe(true);
    }
  });
});

