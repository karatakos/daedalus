# Mushi Web Crawler

Simple and very unoptimized attempt at a web Crawler.

General Notes:

- Took much longer than 4 hour target, likely ~ 2 days due to:
  - First version was synchronous without fetch concurrency and was rewritten
  - A few bugs were difficult to track down
  - Boilerplate issues with Node and TS generally

Limitations:

- Ignores sitemap.xml
- Ignores robots.txt
- Does not respect 429 wait time header
- Naively prints output (huge) but far from a proper site map
- Root site and retry/concurrency options hard-coded in CLI (no args supported)
- Concurrency defaults are aggressive due to the size of the size, e.g. no delays per request

Directory structure

mushi
  mushi (lib)
  mushi-cli (cli)

## Build

Step 1. Lib

```bash
cd mushi
npm install
npm run build
npm run test
npm link
```

Step 2. CLI

```bash
cd mushi-cli
npm install
npm link mushi
npm run build
```

## Run

```bash
cd mushi-cli
npm run mushi-cli > output.txt
```
